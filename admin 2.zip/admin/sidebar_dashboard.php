     <div class="span3" id="sidebar">
	             
                    <ul class="nav nav-list bs-docs-sidenav nav-collapse collapse">
                        <li class="active"> <a href="dashboard.php"><i class="icon-chevron-right"></i><i class="icon-home"></i>&nbsp;Dashboard</a> </li>
						<li>
                            <a href="#"><i class="icon-chevron-right"></i><i class="icon-desktop"></i> Here</a>
                        </li>
						<li class="">
                            <a href="#"><i class="icon-chevron-right"></i><i class="icon-building"></i> Here</a>
                        </li>
						<li class="">
                            <a href="#"><i class="icon-chevron-right"></i><i class="icon-sitemap"></i> hERE</a>
                        </li>
						<li>
                            <a href="#"><i class="icon-chevron-right"></i><i class="icon-laptop"></i>hERE</a>
                        </li>	
						<li>
                            <a href="#"><i class="icon-chevron-right"></i><i class="icon-laptop"></i> hERE</a>
                        </li>
						<li class="">
                            <a href="staff_user.php"><i class="icon-chevron-right"></i><i class="icon-user"></i> Staff User</a>
                        </li>
						<li class="">
                            <a href="admin_user.php"><i class="icon-chevron-right"></i><i class="icon-user"></i> System User</a>
                        </li>
						<li class="">
                            <a href="activity_log.php"><i class="icon-chevron-right"></i><i class="icon-file"></i> Activity Log</a>
                        </li>
						
					   <li class="dropdown">
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown"> <i class="icon-chevron-right"></i><i class="icon-search icon-large"></i>&nbsp;Advance Search&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
								<i class="caret"></i>
                                </a>
                               
                            </li>
                    </ul>
					
				<?php include('search_form.php'); ?>
				<?php include('search_form1.php'); ?>										
    </div>